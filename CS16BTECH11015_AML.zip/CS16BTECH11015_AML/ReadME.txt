The /DecisionTrees/.py files have code for implementation of decision trees(written from scratch) using gini/entrophy.


The /Classification/.py files are to determine the cuisine type for given ingredients.

(Refer to the Report to know more)